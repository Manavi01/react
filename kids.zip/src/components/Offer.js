import React from 'react'
import { NavLink } from 'react-router-dom';
import DATA from '../Data1'
const Offer = () => {







const cardItem = (item) => {
return (
<div class="card my-5 py-4" key={item.id} style={{width: "25rem"}}>
<img src= {item.img} class="card-img-top" alt={item.title}/>
<div class="card-body text-center">
<h5 class="card-title">{item.title}</h5>
<p className="lead">{item.price}</p>
{/* <NavLink to={'/products/Rs{item.id}'} class="btn btn-outline-primary">Buy Now</NavLink> */}
</div>
</div>
);
}


return (
<div>
<div className="conatiner py-5">
<div className="row row justify-content-around">
<div className="col-12 text-center">
<h1>PREMIUM BOUTIQUES</h1>
<hr />
</div>

</div>

</div>
<div className="conatiner">
<div className="row justify-content-around">
{DATA.map(cardItem)}
</div>
</div>
</div>
)
}
export default Offer;