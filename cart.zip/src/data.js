import img1 from './img/img1.png';
import img2 from './img/img2.png';
import img3 from './img/img3.png';
import img4 from './img/img4.png';
import img5 from './img/img5.png';
import img6 from './img/img6.png';
import img7 from './img/img7.png';
import img8 from './img/img8.png';
import img9 from './img/img9.png';


const data = {
    productData:[
        {
            id:1,
            img:img1,
            title:'CUCUMBER',
            desc:'',
            price:60,
        },
        
        {
            id:2,
            img:img2,
            title:'CARROT',
            desc:'',
            price:50,
        },
        {
            id:3,
            img:img3,
            title:'BEETROOT',
            desc:'',
            price:80,
        },
        {
            id:4,
            img:img4,
            title:'BRINJAL',
            desc:'',
            price:60,
        },
        {
            id:5,
            img:img5,
            title:'DRUM STICK',
            desc:'',
            price:75,
        },
        {
            id:6,
            img:img6,
            title:'BITTER GOURD',
            desc:'',
            price:50,
        },
        {
            id:7,
            img:img7,
            title:'GUAVA',
            desc:'',
            price:80,
        },
        {
            id:8,
            img:img8,
            title:'CHIKU',
            desc:'',
            price:60,
        },
        {
            id:9,
            img:img9,
            title:'MANGO',
            desc:'',
            price:100,
        }
    ],
};
export default data;
