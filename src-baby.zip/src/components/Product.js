import React from 'react'
import { NavLink } from 'react-router-dom';
import DATA from '../Data'
const Product = () => {

    const cardItem = (item) => {
        return (
            <div class="card my-5 py-4" key={item.id} style={{ width: "25rem" }}>
                <img src={item.img} class="card-img-top" alt={item.title} />
                <div class="card-body text-center">
                    <h5 class="card-title">{item.title}</h5>
                    <p className="lead">₹ {item.price}</p>
                    <NavLink to={'/products/₹{item.id}'} class="btn btn-outline-primary">Buy Now</NavLink>
                </div>
            </div>
        );
    }

    const ShowProducts = () => {
        return (
            <>
                <div className="buttons d-flex justify-content-center mb-5 pb-5">
                    <button className="btn-btn-outline-dark me-2">All</button>
                    <button className="btn-btn-outline-dark me-2">Kid's Clothing</button>
                    <button className="btn-btn-outline-dark me-2">Kid's Skincare</button>
                    <button className="btn-btn-outline-dark me-2">Kid's Toys</button>

                </div>
                
            </>
        )

    }
    return (
        <div>
            <div className="conatiner py-5">
                <div className="row justify-content-around">
                    <div className="col-12 text-center">
                        <h1>Product</h1>
                        <hr />
                    </div>

                </div>
                <div className="row justify-content-center"></div>
                {<ShowProducts />}


            </div>
            
            <div className="conatiner">
                <div className="row justify-content-around">
                    {DATA.map(cardItem)}
                </div>
            </div>
        </div>
    )
}
export default Product